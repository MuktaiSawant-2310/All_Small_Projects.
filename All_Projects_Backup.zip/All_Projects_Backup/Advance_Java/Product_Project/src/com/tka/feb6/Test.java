package com.tka.feb6;

import java.util.ArrayList;
import java.util.List;

public class Test {
	public static void main(String[] args) {

		List<Product> products = new ArrayList<>();
		Product p = new Product();

		products.add(new Product(1, "Laptop", "Electronics", 50000));
		products.add(new Product(2, "Vegetables", "Grocery", 50000));
		products.add(new Product(3, "Cloths", "Clothing", 50000));
		products.add(new Product(4, "Mobile", "Mobile", 50000));
		products.add(new Product(5, "Sofa", "Furniture", 50000));

		for (Product p1 : products) {
			System.out.println(p1);
		}

		for (Product p1 : products) {
			if(p1.category.equalsIgnoreCase("Mobile"))
				System.out.println(p1);
		}

	}

}
