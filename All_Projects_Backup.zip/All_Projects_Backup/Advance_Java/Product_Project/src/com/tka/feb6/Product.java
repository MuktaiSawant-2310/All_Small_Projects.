package com.tka.feb6;

public class Product {

	int p_id;
	String p_name;
	String category;
	double price;

	public Product(int p_id, String p_name, String category, double price) {
		super();
		this.p_id = p_id;
		this.p_name = p_name;
		this.category = category;
		this.price = price;
	}

	public Product() {
		super();
	}

	@Override
	public String toString() {
		return "Product [p_id=" + p_id + ", p_name=" + p_name + ", category=" + category + ", price=" + price + "]";
	}

}
