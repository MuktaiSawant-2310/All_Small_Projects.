package com.tka;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class InsertIntoStudent {

	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction bt = session.beginTransaction();
		
		Student s1=new Student(1, "Muktai","Pune","Java",89.20);
		Student s2=new Student(3, "Muktai","Pune","Java",89.20);

		
		session.save(s1);
		session.save(s2);
		bt.commit();
		sf.close();
		
		
		
		System.out.println("Inserted Successfully....!");
	}
}
