package com.tka;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Student_Info")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int stu_id;
	String name;
	String city;
	String course;
	double marks;
	
	public Student() {
		super();
	}

	public Student(int stu_id, String name, String city, String course, double marks) {
		super();
		this.stu_id = stu_id;
		this.name = name;
		this.city = city;
		this.course = course;
		this.marks = marks;
	}

	public int getStu_id() {
		return stu_id;
	}

	public void setStu_id(int stu_id) {
		this.stu_id = stu_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public double getMarks() {
		return marks;
	}

	public void setMarks(double marks) {
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "Student [stu_id=" + stu_id + ", name=" + name + ", city=" + city + ", course=" + course + ", marks="
				+ marks + "]";
	}

	
	

}
