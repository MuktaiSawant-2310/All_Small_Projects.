package com.tka;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DeleteIntoStudent {
	
	public static void main(String[] args) {
		
		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction bt = session.beginTransaction();
		
		Student s1=session.get(Student.class, 3);
		session.delete(s1);
		bt.commit();
		session.close();
		sf.close();
		
		System.out.println("Data Deleted Successfully...!");
	}

}
