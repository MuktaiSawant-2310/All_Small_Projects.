package com.tka;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UpdateIntoStudent {
	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction bt = session.beginTransaction();
		
		Student s1=new Student(2, "Muktai Sawant","Beed","Mumbai", 0);
		
		session.update(s1);
		bt.commit();
		
		sf.close();
		session.close();
		
		System.out.println("Data Updated Suucessfully....!");
	}

}
