package com.tka.feb6;

import java.util.ArrayList;
import java.util.List;

public class MainApp {

	public static void main(String[] args) {

		List<Product> product_details = new ArrayList<Product>();

		//Product List
		product_details.add(new Product(101, "Pizza", "FastFood", 200));
		product_details.add(new Product(102, "VadaPav", "FastFood", 15));
		product_details.add(new Product(103, "Samosa", "FastFood", 20));
		product_details.add(new Product(104, "Biryani", "Non-Veg", 90));
		product_details.add(new Product(105, "Pasta", "Veg", 35));

		//Customer List
		Customer c1 = new Customer(11, "Muktai", 7378990000l);
		
		//Customer  Products  List
		List<Product> customerProductList = new ArrayList<>();
		customerProductList.add(product_details.get(0));
		customerProductList.add(product_details.get(3));

		Order od = new Order(1, c1, customerProductList);
		od.displayOrder();

		double total = Order.calculateTotal(customerProductList);
		System.out.println("Total Bill = " + total);

	}

}
