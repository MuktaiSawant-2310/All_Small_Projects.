package com.tka.feb6;

import java.util.List;

public class Order {

	int order_id;
	Customer customer;
	List<Product> custProductList;
	double totalAmount;

	public Order(int order_id, Customer customer, List<Product> custProductList) {
		super();
		this.order_id = order_id;
		this.customer = customer;
		this.custProductList = custProductList;
	}

	public void displayOrder() {
		System.out.println("Customer Details:");
		System.out.println(customer);
		System.out.println("Product  Details:");

		for (Product p : custProductList) {
			System.out.println("Name = " + p.getP_name() + "   Price = " + p.getPrice());
		}
	}

	public static double calculateTotal(List<Product> productList) {
		double totalAmount = 0;

		for (Product p : productList) {
			totalAmount += p.getPrice();
		}
		return totalAmount;
	}

}
