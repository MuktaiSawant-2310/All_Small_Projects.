package com.tka.feb6;

public class Customer {

	int c_id;
	String c_name;
	long mob;

	public Customer(int c_id, String c_name, long mob) {
		super();
		this.c_id = c_id;
		this.c_name = c_name;
		this.mob = mob;
	}

	public int getC_id() {
		return c_id;
	}

	public void setC_id(int c_id) {
		this.c_id = c_id;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public long getMob() {
		return mob;
	}

	public void setMob(long mob) {
		this.mob = mob;
	}

	@Override
	public String toString() {
		return "Customer [c_id=" + c_id + ", c_name=" + c_name + ", mob=" + mob + "]";
	}

}
