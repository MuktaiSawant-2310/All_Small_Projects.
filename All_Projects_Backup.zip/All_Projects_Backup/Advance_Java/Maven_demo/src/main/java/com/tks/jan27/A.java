package com.tks.jan27;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class A {

	public static void main(String[] args) {
		System.out.println("Hello Java ");
		Connection connection;

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Loaded ....");

			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "admin");
			System.out.println("Connection Establish Successful ");

			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("SELECT * FROM student.student_info");

			while (rs.next()) {
				Student s = new Student();
				s.setRollno(rs.getInt(1));
				s.setName(rs.getString(2));
				s.setCourse(rs.getString(3));
				s.setPercentage(rs.getDouble(4));

				System.out.println(s);
//			    int rollno = rs.getInt(1);
//			    String name = rs.getString(2);
//			    String course = rs.getString(3);
//			    double percentage = rs.getDouble(4);

//			    System.out.println(rollno + " " + name + " " + course + " " + percentage);
			}

			connection.close();
			statement.close();
			rs.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

//		connection.close();

	}

}
