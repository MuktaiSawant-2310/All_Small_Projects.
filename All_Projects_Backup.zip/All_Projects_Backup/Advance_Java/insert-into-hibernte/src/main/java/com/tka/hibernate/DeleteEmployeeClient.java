package com.tka.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DeleteEmployeeClient {
	
	public static void main(String[] args) {
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(Employee.class);
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction bt = session.beginTransaction();
		
		Employee e1=session.get(Employee.class, 102);
		session.delete(e1);
		
		bt.commit();
		session.close();
		sf.close();
		
		System.out.println("Deleted Successfully....!");
		
		
	}

}
