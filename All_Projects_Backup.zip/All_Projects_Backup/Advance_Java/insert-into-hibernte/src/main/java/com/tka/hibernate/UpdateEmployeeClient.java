package com.tka.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UpdateEmployeeClient {
	public static void main(String[] args) {
		
		System.out.println("Update");
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(Employee.class);
		
		SessionFactory session = cfg.buildSessionFactory();
		Session openSession = session.openSession();
		Transaction beginTransaction = openSession.beginTransaction();
		
		
		Employee e1= new Employee();
		e1.setE_id(101);
		e1.setName("Muktai Updated");
		e1.setDepartment("Developer");
		e1.setSalary(70000.00);
		
		openSession.update(e1);
		beginTransaction.commit();
		openSession.close();
		session.close();
		
		System.out.println("Thanks   ");
		
	}
}
