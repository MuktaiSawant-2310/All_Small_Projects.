package com.tka.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class InsertEmployeeClient {

    public static void main(String[] args) {

        System.out.println("Welcome");

//        Employee e1 = new Employee(101, "Muktai", "IT", 50000.00);
        Employee e2 = new Employee(102,"Pallavi","Cloud",40000);
        Employee e3 = new Employee(103,"Rajeshrii","IT",60000);


        Configuration hbCnfg = new Configuration();
        hbCnfg.configure("hibernate.cfg.xml");
        hbCnfg.addAnnotatedClass(Employee.class);
//        System.out.println("This is a Sql Query");

        SessionFactory sf = hbCnfg.buildSessionFactory();
        Session session = sf.openSession();

        Transaction tx = session.beginTransaction();
//        session.save(e1);
        session.save(e2);
        session.save(e3);
        tx.commit();

        session.close();
        sf.close();

        System.out.println("Thanks");
    }
}
