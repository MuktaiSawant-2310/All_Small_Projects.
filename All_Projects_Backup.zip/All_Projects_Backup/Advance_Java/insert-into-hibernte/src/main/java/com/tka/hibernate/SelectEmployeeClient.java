package com.tka.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SelectEmployeeClient {
	
	public static void main(String[] args) {
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(Employee.class);
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		Employee employee = session.get(Employee.class, 101);
		
		System.out.println("Employee Details ");
		System.out.println(employee);
		
		System.out.println("***** Thanks *******");
	}

}
