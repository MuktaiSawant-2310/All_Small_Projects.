package com.tka.advJava;

import java.util.List;

public class Order {
	
	int order_id;
	Customer customer;
	List<Product> custProductList;
	
	public Order(int order_id, Customer customer, List<Product> custProductList) {
		super();
		this.order_id = order_id;
		this.customer = customer;
		this.custProductList = custProductList;
	}
	
	public void displayOrder() {
        System.out.println("Order ID: " + order_id);
        System.out.println("Customer Details:");
        System.out.println(customer);
        System.out.println("Products:");

        for (Product p : custProductList) {
            System.out.println(p);
        }

//        System.out.println("Total Bill: " + totalBill);
    }
}
	
	
	
	


