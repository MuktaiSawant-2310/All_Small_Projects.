package com.tka.advJava;

import java.util.List;

public class Customer {
	
	private int id;
	private String name;
	private long mob;
	private String address;
	private List<Product> products;
	
	public Customer(int id, String name, long mob, String address) {
		super();
		this.id = id;
		this.name = name;
		this.mob = mob;
		this.address = address;
	}
	
//	List<Product> product_details=new ArrayList<Product>();
	
//	product_details.add(new Product(101, "Mobile", 20000));
//	product_details.add(new Product(102, "Laptop", 70000));
//	product_details.add(new Product(103, "Mouse", 200));
//	product_details.add(new Product(104, "Keybord", 2000));
//	product_details.add(new Product(105, "Notebook", 20));

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMob() {
		return mob;
	}

	public void setMob(long mob) {
		this.mob = mob;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", mob=" + mob + ", address=" + address + "]";
	}

	
}
