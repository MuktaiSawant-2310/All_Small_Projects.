package com.tka.advJava;

import java.util.List;

public class TotalBill {
	
	public static double calculateTotal(List<Product> productList) {
        double total = 0;

        for (Product p : productList) {
            total += p.getPrice();
        }
        return total;
    }

}
