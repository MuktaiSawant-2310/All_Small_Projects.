package com.tka.advJava;

import java.util.ArrayList;
import java.util.List;

public class MainApp {

	public static void main(String[] args) {

		List<Product> product_details = new ArrayList<Product>();

		product_details.add(new Product(101, "Pizza", 200));
		product_details.add(new Product(102, "VadaPav", 15));
		product_details.add(new Product(103, "Samosa", 20));
		product_details.add(new Product(104, "Tea", 12));
		product_details.add(new Product(105, "Coffee", 30));

		Customer c1 = new Customer(11, "Muktai", 7378990000l, "Karve Nagar");
//		System.out.println("Customer Created ");

		List<Product> customerProductList = new ArrayList<>();
		customerProductList.add(product_details.get(2));
		customerProductList.add(product_details.get(3));

//		System.out.println("All Details");
//		System.out.println("Customer Details");
//		System.out.println(c1);
		
		Order od=new Order(1, c1, customerProductList);
		od.displayOrder();
		
		TotalBill tb=new TotalBill();
		double total = tb.calculateTotal(customerProductList);
		System.out.println("Total Bill = "+total);

//		customerProductList.forEach(System.out::println);
//
//		double totalBill = 0;
//		for (Product product : customerProductList) {
//			totalBill += product.getPrice();
//		}
//
//		System.out.println("Total Bill : " + totalBill);
////		for(Product p:product_details) {
////			System.out.println(p);
////			}
	}

}
