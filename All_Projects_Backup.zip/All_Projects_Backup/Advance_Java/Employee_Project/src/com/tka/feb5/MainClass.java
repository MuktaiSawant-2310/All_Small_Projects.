package com.tka.feb5;

import java.util.ArrayList;
import java.util.List;

public class MainClass {

	public static void main(String[] args) {
		List<Employee> emplist = new ArrayList<>();

		Employee e1 = new Employee(1, "Muktai", "Developer", 70000.00);
		Employee e2 = new Employee(2, "Sakshi", "Developer", 20000.00);
		Employee e3 = new Employee(3, "Shivani", "Tester", 50000.00);
		Employee e4 = new Employee(4, "Rajeshrii", "Tester", 40000.00);
		Employee e5 = new Employee(5, "pallavi", "Developer", 30000.00);

		emplist.add(e1);
		emplist.add(e2);
		emplist.add(e3);
		emplist.add(e4);
		emplist.add(e5);

		for (Employee e : emplist) {
			System.out.println(e);
		}

		System.out.println("\n \n Those Employee Having Role Tester");
		for (Employee e : emplist) {
			if (e.getRole().equalsIgnoreCase("Tester"))
				System.out.println(e);
		}

		System.out.println("\n \n Those Employee Having Role Developer");
		for (Employee e : emplist) {
			if (e.getRole().equalsIgnoreCase("Developer"))
				System.out.println(e);
		}

		System.out.println("\n \n Those Employee Having Role Developer and Salary >20000");
		for (Employee e : emplist) {
			if (e.getRole().equalsIgnoreCase("Developer") && e.getSalary() > 20000)
				System.out.println(e);
		}

		System.out.println("\n Update Salary Based On Condition");
		for (Employee e : emplist) {

			if (e.getSalary() < 10000)
				e.setSalary((e.getSalary() + e.getSalary() * 0.10));
			else if (e.getSalary() >= 10000 && e.getSalary() <= 20000)
				e.setSalary((e.getSalary() + e.getSalary() * 0.15));
			else if (e.getSalary() > 20000)
				e.setSalary((e.getSalary() + e.getSalary() * 0.20));
		}

		System.out.println("\n After Salary Update");
		for (Employee ee : emplist) {
			System.out.println(ee);
		}
		
		//Accending and Dessending Order is Remaining
	}

}
