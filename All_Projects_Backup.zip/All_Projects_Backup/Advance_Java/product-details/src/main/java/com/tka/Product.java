package com.tka;

public class Product {

	int P_id;
	String P_Name;
	double p_price;
	int p_Quentity;

	public Product() {
		super();
	}

	public Product(int p_id, String p_Name, double p_price, int p_Quentity) {
		super();
		P_id = p_id;
		P_Name = p_Name;
		this.p_price = p_price;
		this.p_Quentity = p_Quentity;
	}

	public int getP_id() {
		return P_id;
	}

	public void setP_id(int p_id) {
		P_id = p_id;
	}

	public String getP_Name() {
		return P_Name;
	}

	public void setP_Name(String p_Name) {
		P_Name = p_Name;
	}

	public double getP_price() {
		return p_price;
	}

	public void setP_price(double p_price) {
		this.p_price = p_price;
	}

	public int getP_Quentity() {
		return p_Quentity;
	}

	public void setP_Quentity(int p_Quentity) {
		this.p_Quentity = p_Quentity;
	}

	@Override
	public String toString() {
		return "Product [P_id=" + P_id + ", P_Name=" + P_Name + ", p_price=" + p_price + ", p_Quentity=" + p_Quentity
				+ "]";
	}

}
