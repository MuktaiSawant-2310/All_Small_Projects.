package com.tka;
import org.hibernate.SessionFactory;


public class HibernateUtil {
	
	public static SessionFactory factory;
	

}
