package com.logic;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Fo_Service {

	public Food calculateBill(Food order) {
		double total = order.getPrice() * order.getQuantity();
		double gst = total * 0.05;
		double finalBill = total + gst;

		order.setTotal(total);
		order.setGst(gst);
		order.setFinalBill(finalBill);

		// Hibernate Connection

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction bt = session.beginTransaction();

		session.save(order);
		session.getTransaction().commit();
		session.close();

		return order;

	}

}
