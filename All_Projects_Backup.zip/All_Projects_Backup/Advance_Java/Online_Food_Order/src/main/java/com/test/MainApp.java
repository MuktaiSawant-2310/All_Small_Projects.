package com.test;

import com.logic.Fo_Service;

import com.logic.Food;

public class MainApp {

	public static void main(String[] args) {

		System.out.println("******* Welcome to Online_Food_Order System *********");

		Food f = new Food();
		f.setRestaurant("Spicy Hub");
//		f.setItemName("Vadapav");
		f.setItemName("Vadapav");
		f.setPrice(30);
		f.setQuantity(3);

		Food f2 = new Food();
		f2.setRestaurant("Muktai's Restaurant");
		f2.setItemName("Samosa");
		f2.setPrice(40);
		f2.setQuantity(2);

		Fo_Service fs = new Fo_Service();
		Food result = fs.calculateBill(f);
		Food result2 = fs.calculateBill(f2);

		System.out.println(result);
		System.out.println(result2);

	}

}
