package com.logic;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "food_Order")
public class Food {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int item_Id;
	String restaurant;
	String itemName;
	double price;
	int quantity;
	double total;
	double gst;
	double finalBill;

	public Food() {
		super();
	}

	public Food(int item_Id, String itemName, double price, int quantity) {
		super();
		this.item_Id = item_Id;
		this.itemName = itemName;
		this.price = price;
		this.quantity = quantity;
	}

	public int getItem_Id() {
		return item_Id;
	}

	public void setItem_Id(int item_Id) {
		this.item_Id = item_Id;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(String restaurant) {
		this.restaurant = restaurant;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public double getGst() {
		return gst;
	}

	public void setGst(double gst) {
		this.gst = gst;
	}

	public double getFinalBill() {
		return finalBill;
	}

	public void setFinalBill(double finalBill) {
		this.finalBill = finalBill;
	}

	@Override
	public String toString() {
		return "Food Details \n item_Id = " + item_Id + "\n restaurant = " + restaurant + "\n itemName = " + itemName
				+ "\n price = " + price + "\n quantity = " + quantity + "\n total = " + total + "\n gst = " + gst
				+ "\n finalBill = " + finalBill;
	}

}
