package com.tka.jan22;

import java.sql.SQLException;
import java.util.List;

public class MainApp {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
	

		        int orderId = 1;

		        Customer customer = Customer_DAO.getCustomer(11);
		        List<Product> products = Product_DAO.getProductByOrder(orderId);

		        System.out.println("Customer Details:");
		        System.out.println(customer);

		        System.out.println("Products:");
		        for (Product p : products) {
		            System.out.println(p);
		        }

		        double total = TotalBill.calculate(products);
		        System.out.println("Total Bill: " + total);
		    }
		}

		
	


