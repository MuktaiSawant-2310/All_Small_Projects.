package com.tka.jan22;

import java.util.List;

public class TotalBill {
	
	public static double calculate(List<Product> Products) {
		
		double total=0;
		
		for(Product p:Products) {
			total+=p.getPrice();
		}
		return total;
	}

}
