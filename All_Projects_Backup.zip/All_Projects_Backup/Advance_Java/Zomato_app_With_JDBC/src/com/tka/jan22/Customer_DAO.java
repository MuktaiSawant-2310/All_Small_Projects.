package com.tka.jan22;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Customer_DAO {
	
	public static Customer getCustomer(int id) throws ClassNotFoundException, SQLException {
		
		Connection cn = DBConnection.getConnection();
		
		PreparedStatement statement = cn.prepareStatement("SELECT * FROM  customer");
//		statement.setInt(1, id);
		
		ResultSet rs = statement.executeQuery();
		Customer customer;
		while(rs.next()) {
			int c_id=rs.getInt(0);
			String name=rs.getString(1);
			long mobile=rs.getLong(3);
			String address=	rs.getString(4);
			customer=new Customer(c_id,name,mobile,address);
		}
		return null;
		
	}
	

}
