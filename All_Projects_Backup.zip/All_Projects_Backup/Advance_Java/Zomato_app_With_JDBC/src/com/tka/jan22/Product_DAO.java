package com.tka.jan22;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Product_DAO {
	
	public static List<Product> getProductByOrder(int O_id) throws SQLException, ClassNotFoundException{
		List<Product> list=new ArrayList<>();
		
		Connection connection = DBConnection.getConnection();
		
		String Query="SELECT p.pid, p.pname, p.price \n"
				+ "FROM product p JOIN orders o ON p.pid=o.pid " 
				+ "WHERE o.order_id=? ";
		
		PreparedStatement ps = connection.prepareStatement(Query);
		ps.setInt(1, O_id);
		
		ResultSet rs = ps.executeQuery();
		
		while (rs.next()) {
		    list.add(new Product(
		        rs.getInt("pid"),
		        rs.getString("pname"),
		        rs.getDouble("price")
		    ));
		}

		return list;
	}

}
