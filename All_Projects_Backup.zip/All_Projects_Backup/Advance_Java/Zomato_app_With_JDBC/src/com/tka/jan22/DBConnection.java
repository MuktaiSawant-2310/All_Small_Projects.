package com.tka.jan22;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName( "com.mysql.cj.jdbc.Driver");//load Driver Class
		
		//Eatablish Connection
		 return DriverManager.getConnection("jdbc:mysql://localhost:3306/batch_1297", "root", "admin");
		
		
	}
}
