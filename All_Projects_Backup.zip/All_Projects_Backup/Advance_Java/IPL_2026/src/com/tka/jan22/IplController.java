package com.tka.jan22;

import java.util.ArrayList;
import java.util.List;

public class IplController {
	IplService service = null;

	IplController() {
		service = new IplService();
	}

	public List<Player> getAllPlayers() {
		List<Player> playerList = service.getAllPlayers();

		return playerList;
	}// Developed By the TCS DEVELOPER

	public List<Player> getAllPlayersByCategory(String Categoryreq) {
		List<Player> playerList = service.getAllPlayersByCategory(Categoryreq);

		return playerList;
	}

	public List<Player> getBollerPlayers(String category) {
		service = new IplService();
		List<Player> playerList = service.getBollerPlayers(category);

		return playerList;
	}

	public List<Player> displayById(int P_id2) {
		List<Player> playerList = service.displayById(P_id2);
		return playerList;
	}

	public List<Player> getPlayersByTN(String team_name) {
		List<Player> playerList = service.getPlayersByTN(team_name);
		return playerList;
	}

	public List<Player> getPlayerHighestScore() {
		List<Player> playerList = service.getPlayerHighestScore();
		return playerList;
	}

	public List<Player> getMaxWicketPlayer() {
		List<Player> playerList = service.getMaxWicketPlayer();
		return playerList;
	}

	public Player updatePlayers() {
		Player pr = service.updatePlayers();
		return pr;
	}

	public void deletePlayer() {
		service.deletePlayer();
//		return deletePlayer;

	}

}
