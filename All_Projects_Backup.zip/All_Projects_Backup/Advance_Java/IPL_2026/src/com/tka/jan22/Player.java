package com.tka.jan22;

public class Player {
	
	int p_id;
	String  name;
	String team_name;
	String category;
	int score;
	int catches;
	int wickets;
	
	
	public Player() {
		super();
	}

	public Player(int p_id, String name, String team_name, String category, int score, int catches, int wickets) {
		super();
		this.p_id = p_id;
		this.name = name;
		this.team_name = team_name;
		this.category = category;
		this.score = score;
		this.catches = catches;
		this.wickets = wickets;
	}

	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTeam_name() {
		return team_name;
	}

	public void setTeam_name(String team_name) {
		this.team_name = team_name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getCatches() {
		return catches;
	}

	public void setCatches(int catches) {
		this.catches = catches;
	}

	public int getWickets() {
		return wickets;
	}

	public void setWickets(int wickets) {
		this.wickets = wickets;
	}

	@Override
	public String toString() {
		return "Player [p_id=" + p_id + ", name=" + name + ", team_name=" + team_name + ", category=" + category
				+ ", score=" + score + ", catches=" + catches + ", wickets=" + wickets + "]";
	}

	
}
