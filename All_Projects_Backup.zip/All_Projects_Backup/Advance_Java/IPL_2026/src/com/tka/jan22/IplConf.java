package com.tka.jan22;

import java.sql.Connection;
import java.sql.DriverManager;

public class IplConf {

	public static Connection getIPLDBConnection() {
		Connection connection = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ipl_system", "root", "admin");
			// If Database Not Created Then Write Query (ipl_system?createDatabaseIfNotExist
			// = true "
//			System.out.println("Connection Done...!");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return connection;

	}
}
