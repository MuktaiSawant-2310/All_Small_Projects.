package com.tka.jan22;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class IplDao {

	Connection connection = null;
	String query = null;
	Statement statement = null;
	ResultSet rs = null;

	public List<Player> getAllPlayers() {
		List<Player> playerList = new ArrayList<>();

		try {
			connection = IplConf.getIPLDBConnection();
			query = "select * from ipl_system.Player";
			statement = connection.createStatement();
			rs = statement.executeQuery(query);

			while (rs.next()) {
				Player player = new Player();
				player.setP_id(rs.getInt(1));
				player.setName(rs.getString(2));
				player.setTeam_name(rs.getString(3));
				player.setCategory(rs.getString(4));
				player.setScore(rs.getInt(5));
				player.setCatches(rs.getInt(6));
				player.setWickets(rs.getInt(7));

				playerList.add(player);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return playerList;
	} // capgemini

	public List<Player> updatePlayers() {
		List<Player> updatedList = new ArrayList<>();

		try {
			connection = IplConf.getIPLDBConnection();
			query = "UPDATE ipl_system.Player SET score = ? WHERE p_id= ? ";
			PreparedStatement statement2 = connection.prepareStatement(query);
			statement2.setInt(1, 1000);
			statement2.setInt(2, 1);

			statement2.executeUpdate();

			while (rs.next()) {
				Player player = new Player();
				player.setP_id(rs.getInt(1));
				player.setName(rs.getString(2));
				player.setTeam_name(rs.getString(3));
				player.setCategory(rs.getString(4));
				player.setScore(rs.getInt(5));
				player.setCatches(rs.getInt(6));
				player.setWickets(rs.getInt(7));

				updatedList.add(player);

			}

			System.out.println("Updated Successfull..");

		} catch (Exception e) {
			e.printStackTrace();

		}

		return updatedList;
	}

	public List<Player> deletePlayer() {
		List<Player> deletePlayer = new ArrayList<>();

		try {
			connection = IplConf.getIPLDBConnection();
			query = "DELETE FROM ipl_system.Player WHERE p_id = ?";
			PreparedStatement statement2 = connection.prepareStatement(query);
			statement2.setInt(1, 4);

			statement2.executeUpdate();

			while (rs.next()) {
				Player player = new Player();
				player.setP_id(rs.getInt(1));
				player.setName(rs.getString(2));
				player.setTeam_name(rs.getString(3));
				player.setCategory(rs.getString(4));
				player.setScore(rs.getInt(5));
				player.setCatches(rs.getInt(6));
				player.setWickets(rs.getInt(7));

				deletePlayer.add(player);

			}

			System.out.println("Deleted  Successfull..");

			return null;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return deletePlayer;

	}
}
