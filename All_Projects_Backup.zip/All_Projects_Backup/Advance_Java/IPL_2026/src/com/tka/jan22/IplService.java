package com.tka.jan22;

import java.util.ArrayList;
import java.util.List;

public class IplService {
	IplDao id = null;

	IplService() {
		id = new IplDao();
	}

	public List<Player> getAllPlayers() {
		List<Player> playerList = id.getAllPlayers();

		return playerList;
	}// Infoysis

	public List<Player> getAllPlayersByCategory(String Categoryreq) {

		List<Player> playerList = id.getAllPlayers();
		List<Player> allBatsman = new ArrayList<>();

		for (Player p : playerList) {
			if (p.getCategory().equalsIgnoreCase(Categoryreq)) {
				allBatsman.add(p);
			}
		}
		return allBatsman;
	}

	public List<Player> getBollerPlayers(String category) {
		List<Player> playerList = id.getAllPlayers();
		List<Player> allBoller = new ArrayList<>();

		for (Player p : playerList) {
			if (p.getCategory().equalsIgnoreCase(category)) {
				allBoller.add(p);
			}
		}
		return allBoller;
	}

	public List<Player> displayById(int P_id2) {
		List<Player> playerList = id.getAllPlayers();
		List<Player> ById = new ArrayList<>();

		for (Player p : playerList) {
			if (p.getP_id() == P_id2) {
				ById.add(p);
			}
		}

		return ById;
	}

	public List<Player> getPlayersByTN(String team_name) {

		List<Player> playerList = id.getAllPlayers();
		List<Player> ByTeamName = new ArrayList<>();

		for (Player p : playerList) {
			if (p.getTeam_name().equalsIgnoreCase(team_name)) {
				ByTeamName.add(p);
			}
		}

		return ByTeamName;
	}

	public List<Player> getPlayerHighestScore() {

		List<Player> PlayerList = id.getAllPlayers();
		List<Player> highestScore = new ArrayList<>();
		int maxScore = 0;

		for (Player p : PlayerList) {

			if (p.getScore() > maxScore) {
				maxScore = p.getScore();
			}
		}

		for (Player p : PlayerList) {
			if (p.getScore() == maxScore) {
				System.out.println(p);
			}
		}
		return highestScore;
	}

	public List<Player> getMaxWicketPlayer() {
		List<Player> allPlayer = id.getAllPlayers();
		List<Player> maxWicketsPlayer = new ArrayList<>();
		int maxwickets = 0;

		for (Player p : allPlayer) {
			if (p.getWickets() > maxwickets) {
				maxwickets = p.getWickets();
			}
		}
		for (Player p : allPlayer) {
			if (p.getWickets() == maxwickets) {
				System.out.println(p);
			}
		}

		return maxWicketsPlayer;
	}

	public Player updatePlayers() {
		List<Player> PlayerList = id.getAllPlayers();
		List<Player> updatedPlayers = id.updatePlayers();

		for (Player p : PlayerList) {
			if (p.getP_id() == 1) {
				System.out.println(p);
			}
		}

	}

	public void deletePlayer() {
		List<Player> PlayerList = id.getAllPlayers();
		List<Player> deletePlayer = id.deletePlayer();

		
	}

}
