package com.tka.jan22;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MainApp {

	public static void main(String[] args) {
		System.out.println("***** Welcome to www.ipl.com *****");

		IplController ic = new IplController();
		List<Player> allPlayer = ic.getAllPlayers();
		Player um = ic.updatePlayers();
		List<Player> updatePlayers = updatePlayers2;
		List<Player> updatedPlayer = updatePlayers;

		System.out.println(" 1. Player Details: ");
		allPlayer.forEach(System.out::println);

		// Display all players details whose category is batsman
		String Categoryreq = "Batsman";
		System.out.println(" 2. Display Players details Only >>" + Categoryreq);

		List<Player> allBatsman = ic.getAllPlayersByCategory(Categoryreq);
		allBatsman.forEach(System.out::println);

		// Display all Players Details whose Category is Boller
		String Category = "Bowler";
		System.out.println("3. Display Players Whose Category is >>> " + Category);

		List<Player> allBoller = ic.getBollerPlayers(Category);
		allBoller.forEach(System.out::println);

		// Display Player Details By Using Player Id
		int P_id2 = 2;
		System.out.println("4. Display Details By Using >>> " + P_id2 + " :- ");
		List<Player> ById = ic.displayById(P_id2);
		ById.forEach(System.out::println);

		// Display Player Details By Using Team Name
		String team_name = "India";
		System.out.println("5. Display Players With Team_Name >>> " + team_name);

		List<Player> ByTeamName = ic.getPlayersByTN(team_name);
		ByTeamName.forEach(System.out::println);

		// Diaplay Player details having the highest Score
		System.out.println("\n \n 6. Display Player Having Highest Score >> ");
		List<Player> highestScore = ic.getPlayerHighestScore();
		highestScore.forEach(System.out::println);

		// Display Player Having Maximum Wickets
		System.out.println("\n 7. Displayer Player Having Maximim Wickets >> ");
		List<Player> maxWicketsPlayer = ic.getMaxWicketPlayer();
		maxWicketsPlayer.forEach(System.out::println);

		// Updated Player Score Where ID = ?
		System.out.println("\n 8. Updated Player Score  where P_id ==  >>> 1");
		ic.updatePlayers();

		// Delete Player where Id=?
		System.out.println("\n 9. Delete Player Where P_id = ? ");
		ic.deletePlayer();

		System.out.println("\n---- Thank You For Using this side ----");

	}

}
